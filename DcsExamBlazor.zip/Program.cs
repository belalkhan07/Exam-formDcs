using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using DcsExamApp.Data;
using Microsoft.EntityFrameworkCore;
using DcsExamApp.Models;
using Microsoft.AspNetCore.Identity;
using DcsExamApp.Services.Payment;
using DcsExamApp.Services.Receipt;
using DcsExamApp.Helpers;
using System;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddHttpClient();

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<ApplicationUser, IdentityRole<Guid>>(options => {
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
})
    .AddEntityFrameworkStores<AppDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options => {
    options.LoginPath = "/Identity/Account/Login";
    options.LogoutPath = "/Identity/Account/Logout";
});

builder.Services.AddScoped<RazorpayService>();
builder.Services.AddScoped<ReceiptService>();
builder.Services.AddScoped<JwtTokenHelper>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var db = services.GetRequiredService<AppDbContext>();
        db.Database.Migrate();

        var roleManager = services.GetRequiredService<RoleManager<IdentityRole<Guid>>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();

        if (!roleManager.RoleExistsAsync("Admin").Result) roleManager.CreateAsync(new IdentityRole<Guid>("Admin")).Wait();
        if (!roleManager.RoleExistsAsync("User").Result) roleManager.CreateAsync(new IdentityRole<Guid>("User")).Wait();

        var adminEmail = "admin@dcs.com";
        if (userManager.FindByEmailAsync(adminEmail).Result == null)
        {
            var admin = new ApplicationUser { UserName = adminEmail, Email = adminEmail, FullName = "Dcs Admin" };
            userManager.CreateAsync(admin, "Admin@123").Wait();
            userManager.AddToRoleAsync(admin, "Admin").Wait();
        }
    }
    catch (Exception ex) { var logger = app.Services.GetRequiredService<ILogger<Program>>(); logger.LogError(ex, "DB init error"); }
}

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
