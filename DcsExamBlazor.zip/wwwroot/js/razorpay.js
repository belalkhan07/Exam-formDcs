window.openRazorpay = (key, orderId, amount, dotNetRef) => {
  const options = {
    key: key,
    amount: amount,
    currency: 'INR',
    order_id: orderId,
    handler: function (response) {
      dotNetRef.invokeMethodAsync('RazorpayHandler', response.razorpay_payment_id, response.razorpay_order_id, response.razorpay_signature);
    },
    modal: { ondismiss: function () { console.log('payment dismissed'); } }
  };
  const rzp = new Razorpay(options);
  rzp.open();
}
