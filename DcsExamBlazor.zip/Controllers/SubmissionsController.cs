using Microsoft.AspNetCore.Mvc;
using DcsExamApp.Data;
using DcsExamApp.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;

namespace DcsExamApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SubmissionsController : ControllerBase
    {
        private readonly AppDbContext _db;
        public SubmissionsController(AppDbContext db) => _db = db;

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Create(CreateSubmissionDto dto)
        {
            var form = await _db.Forms.FirstOrDefaultAsync(f => f.Slug == dto.ExamSlug);
            if (form == null) return BadRequest("Form not found");

            var submission = new Submission
            {
                Id = Guid.NewGuid(),
                FormId = form.Id,
                AnswersJson = dto.AnswersJson,
                Amount = dto.Amount,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            var uid = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (Guid.TryParse(uid, out var g)) submission.UserId = g;

            await _db.Submissions.AddAsync(submission);
            await _db.SaveChangesAsync();

            return Ok(new { id = submission.Id, amount = submission.Amount });
        }

        [HttpGet("{id:guid}")]
        [Authorize]
        public async Task<IActionResult> Get(Guid id)
        {
            var sub = await _db.Submissions.FindAsync(id);
            if (sub == null) return NotFound();
            return Ok(sub);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> List() => Ok(await _db.Submissions.ToListAsync());
    }

    public class CreateSubmissionDto
    {
        public string ExamSlug { get; set; } = default!;
        public string AnswersJson { get; set; } = "{}";
        public decimal Amount { get; set; }
    }
}
