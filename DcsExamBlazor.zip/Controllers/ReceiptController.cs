using Microsoft.AspNetCore.Mvc;
using DcsExamApp.Data;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using DcsExamApp.Services.Receipt;
using System;

namespace DcsExamApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReceiptController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly ReceiptService _receipt;

        public ReceiptController(AppDbContext db, ReceiptService receipt) { _db = db; _receipt = receipt; }

        [HttpGet("submission/{id:guid}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var payment = await _db.Payments.FirstOrDefaultAsync(p => p.SubmissionId == id && p.Status == "Captured");
            if (payment == null) return NotFound();
            var submission = await _db.Submissions.FindAsync(id);
            var form = await _db.Forms.FindAsync(submission.FormId);
            var user = submission.UserId.HasValue ? await _db.Users.FindAsync(submission.UserId.Value) : null;
            var pdf = _receipt.GenerateReceipt(payment, submission, form, user);
            return File(pdf, "application/pdf", $"receipt_{payment.PaymentId ?? payment.OrderId}.pdf");
        }
    }
}
