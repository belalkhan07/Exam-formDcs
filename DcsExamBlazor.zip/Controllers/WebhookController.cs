using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading.Tasks;
using DcsExamApp.Services.Payment;
using DcsExamApp.Data;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using System;

namespace DcsExamApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WebhookController : ControllerBase
    {
        private readonly RazorpayService _razorpay;
        private readonly IConfiguration _config;
        private readonly AppDbContext _db;

        public WebhookController(RazorpayService razorpay, IConfiguration config, AppDbContext db)
        {
            _razorpay = razorpay;
            _config = config;
            _db = db;
        }

        [HttpPost("razorpay")]
        public async Task<IActionResult> Razorpay()
        {
            var body = await new StreamReader(Request.Body).ReadToEndAsync();
            var sig = Request.Headers["X-Razorpay-Signature"].ToString();
            var secret = _config["Razorpay:WebhookSecret"];
            if (!_razorpay.VerifyWebhook(body, sig, secret)) return BadRequest("Invalid signature");

            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;
            var ev = root.GetProperty("event").GetString();
            if (ev == "payment.captured")
            {
                var paymentEntity = root.GetProperty("payload").GetProperty("payment").GetProperty("entity");
                var orderId = paymentEntity.GetProperty("order_id").GetString();
                var paymentId = paymentEntity.GetProperty("id").GetString();
                var amount = paymentEntity.GetProperty("amount").GetDecimal() / 100m;

                var pay = await _db.Payments.FirstOrDefaultAsync(p => p.OrderId == orderId);
                if (pay != null)
                {
                    pay.PaymentId = paymentId;
                    pay.Status = "Captured";
                    await _db.SaveChangesAsync();
                    var sub = await _db.Submissions.FindAsync(pay.SubmissionId);
                    if (sub != null) { sub.Status = "Paid"; await _db.SaveChangesAsync(); }
                }
            }
            return Ok();
        }
    }
}
