using Microsoft.AspNetCore.Mvc;
using DcsExamApp.Data;
using DcsExamApp.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;

namespace DcsExamApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FormsController : ControllerBase
    {
        private readonly AppDbContext _db;
        public FormsController(AppDbContext db) => _db = db;

        [HttpGet]
        public async Task<IActionResult> GetAll() => Ok(await _db.Forms.AsNoTracking().ToListAsync());

        [HttpGet("{slug}")]
        public async Task<IActionResult> GetBySlug(string slug)
        {
            var form = await _db.Forms.AsNoTracking().FirstOrDefaultAsync(f => f.Slug == slug);
            if (form == null) return NotFound();
            return Ok(form);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create(Form model)
        {
            model.Id = Guid.NewGuid();
            model.CreatedAt = DateTime.UtcNow;
            await _db.Forms.AddAsync(model);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetBySlug), new { slug = model.Slug }, model);
        }
    }
}
