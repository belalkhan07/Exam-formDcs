using Microsoft.AspNetCore.Mvc;
using DcsExamApp.Data;
using DcsExamApp.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using DcsExamApp.Services.Payment;
using Microsoft.Extensions.Configuration;
using System;
using System.Text.Json;

namespace DcsExamApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentsController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly RazorpayService _razorpay;
        private readonly IConfiguration _config;

        public PaymentsController(AppDbContext db, RazorpayService razorpay, IConfiguration config)
        {
            _db = db;
            _razorpay = razorpay;
            _config = config;
        }

        [HttpPost("razorpay/order")]
        [Authorize]
        public async Task<IActionResult> CreateRazorpayOrder(CreateRazorpayOrderDto dto)
        {
            var submission = await _db.Submissions.FindAsync(dto.SubmissionId);
            if (submission == null) return BadRequest("Submission not found");
            var amountPaise = (int)(submission.Amount * 100);
            var receiptId = submission.Id.ToString();

            var resp = await _razorpay.CreateOrderAsync(receiptId, amountPaise);
            if (resp == null) return StatusCode(500, "Razorpay order creation failed");

            var orderId = resp.Value.GetProperty("id").GetString();

            var payment = new Payment
            {
                Id = Guid.NewGuid(),
                SubmissionId = submission.Id,
                Provider = "razorpay",
                OrderId = orderId ?? string.Empty,
                Amount = submission.Amount,
                Currency = "INR",
                Status = "Created",
                CreatedAt = DateTime.UtcNow
            };
            await _db.Payments.AddAsync(payment);
            await _db.SaveChangesAsync();

            return Ok(new { orderId = orderId, amount = amountPaise, key = _config["Razorpay:Key"] });
        }

        [HttpPost("razorpay/confirm")]
        [Authorize]
        public async Task<IActionResult> Confirm([FromBody] RazorpayConfirmDto dto)
        {
            var payment = await _db.Payments.FirstOrDefaultAsync(p => p.SubmissionId == dto.SubmissionId && p.OrderId == dto.RazorpayOrderId);
            if (payment == null) return NotFound("Payment not found");
            payment.PaymentId = dto.RazorpayPaymentId;
            payment.Signature = dto.RazorpaySignature;
            payment.Status = "Captured";
            await _db.SaveChangesAsync();

            var submission = await _db.Submissions.FindAsync(dto.SubmissionId);
            if (submission != null) { submission.Status = "Paid"; await _db.SaveChangesAsync(); }

            return Ok(new { ok = true });
        }
    }

    public class CreateRazorpayOrderDto { public Guid SubmissionId { get; set; } public decimal Amount { get; set; } }
    public class RazorpayConfirmDto { public Guid SubmissionId { get; set; } public string RazorpayPaymentId { get; set; } = default!; public string RazorpaySignature { get; set; } = default!; public string RazorpayOrderId { get; set; } = default!; }
}
