DcsExam Blazor - Minimal Package

This archive contains a minimal Blazor Server project scaffold with:
- Program.cs
- appsettings.Development.json
- Data, Models, Services, Controllers, Pages, wwwroot

Steps to run:
1. Extract to a folder.
2. Open the folder in Visual Studio (open the .csproj: DcsExamApp.csproj).
3. Add required NuGet packages (or run 'dotnet restore'):
   - Microsoft.EntityFrameworkCore.SqlServer
   - Microsoft.EntityFrameworkCore.Design
   - Microsoft.AspNetCore.Identity.EntityFrameworkCore
   - QuestPDF
   - Swashbuckle.AspNetCore
   - Newtonsoft.Json
4. Update appsettings.Development.json with your Razorpay test keys or leave placeholders for mock testing.
5. Run EF migrations:
   dotnet tool install --global dotnet-ef
   dotnet ef migrations add InitialCreate
   dotnet ef database update
6. Run the project from Visual Studio or 'dotnet run'.

Note: This is a minimal scaffold designed to get you started. You may need to adjust namespaces or add missing usings if your SDK versions differ.
