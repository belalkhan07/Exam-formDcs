using System;

namespace DcsExamApp.Models
{
    public class Payment
    {
        public Guid Id { get; set; }
        public Guid SubmissionId { get; set; }
        public string Provider { get; set; } = "razorpay";
        public string OrderId { get; set; } = default!;
        public string? PaymentId { get; set; }
        public decimal Amount { get; set; }
        public string Currency { get; set; } = "INR";
        public string Status { get; set; } = "Created";
        public string? Signature { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
