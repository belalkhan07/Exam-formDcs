using System;

namespace DcsExamApp.Models
{
    public class Submission
    {
        public Guid Id { get; set; }
        public Guid? UserId { get; set; }
        public Guid FormId { get; set; }
        public string AnswersJson { get; set; } = "{}";
        public string Status { get; set; } = "Pending";
        public decimal Amount { get; set; } = 0m;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
