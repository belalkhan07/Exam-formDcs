using QuestPDF.Fluent;
using QuestPDF.Infrastructure;
using DcsExamApp.Models;
using System.IO;

namespace DcsExamApp.Services.Receipt
{
    public class ReceiptService
    {
        public byte[] GenerateReceipt(Payment payment, Submission submission, Form form, ApplicationUser? user)
        {
            using var ms = new MemoryStream();

            var doc = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(30);
                    page.DefaultTextStyle(x => x.FontSize(12));
                    page.Header().Text("DCS Technosis Pvt Ltd").FontSize(18).Bold();
                    page.Content().Column(col =>
                    {
                        col.Item().Text($"Receipt: {payment.PaymentId ?? payment.OrderId}").Bold();
                        col.Item().Text($"Name: {user?.FullName ?? user?.Email}");
                        col.Item().Text($"Form: {form?.Title}");
                        col.Item().Text($"Amount: {payment.Amount} {payment.Currency}");
                        col.Item().Text($"Status: {payment.Status}");
                        col.Item().Text($"Date: {payment.CreatedAt:yyyy-MM-dd HH:mm}");
                        col.Item().Text($"Submission Id: {submission.Id}");
                    });
                });
            });

            doc.GeneratePdf(ms);
            return ms.ToArray();
        }
    }
}
