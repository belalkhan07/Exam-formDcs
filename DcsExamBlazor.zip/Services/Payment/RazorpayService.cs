using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System;

namespace DcsExamApp.Services.Payment
{
    public class RazorpayService
    {
        private readonly IConfiguration _config;
        private readonly IHttpClientFactory _httpFactory;
        public RazorpayService(IConfiguration config, IHttpClientFactory httpClientFactory)
        {
            _config = config;
            _httpFactory = httpClientFactory;
        }

        public async Task<JsonElement?> CreateOrderAsync(string receiptId, int amountPaise, string currency = "INR")
        {
            var key = _config["Razorpay:Key"];
            var secret = _config["Razorpay:Secret"];
            var auth = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{key}:{secret}"));

            var client = _httpFactory.CreateClient();
            var payload = new { amount = amountPaise, currency = currency, receipt = receiptId, payment_capture = 1 };
            var req = new HttpRequestMessage(HttpMethod.Post, "https://api.razorpay.com/v1/orders");
            req.Headers.Authorization = new AuthenticationHeaderValue("Basic", auth);
            req.Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json");

            var resp = await client.SendAsync(req);
            if (!resp.IsSuccessStatusCode) return null;
            var text = await resp.Content.ReadAsStringAsync();
            var doc = JsonDocument.Parse(text);
            return doc.RootElement;
        }

        public bool VerifyWebhook(string body, string signature, string secret)
        {
            using var hmac = new System.Security.Cryptography.HMACSHA256(Encoding.UTF8.GetBytes(secret));
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(body));
            var hex = BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            if (signature == hex) return true;
            var b64 = Convert.ToBase64String(hash);
            return signature == b64;
        }
    }
}
